import React, { useEffect, useState } from "react";
import SockJS from "sockjs-client/dist/sockjs";
import { Client, Frame, Message, over } from "stompjs";

let stompClient: Client | null = null;
const ChatRoom = () => {
  // 상수
  const [inputs, setInputs] = useState({ id: 0, name: "", newChannel: 0 });
  const [user, setUser] = useState({
    id: 0,
    name: "",
    message: "",
    loggedin: false,
    connected: false,
  });
  const [channels, setChannels] = useState([
    // {
    //   id: 0,
    //   name: "Basic",
    //   reference: "Basic",
    //   accessType: "PRIVATE",
    //   channelType: "SINGLE",
    // },
  ]);
  const [tab, setTab] = useState("");
  const [chats, setChats] = useState([
    // {
    //   sender: "KTaeGyu",
    //   content: "hello world!",
    //   reference: "Basic",
    //   messageType: "MESSAGE_TXT",
    //   createdTime: "2024-01-22T01:55:00.170Z",
    // },
  ]);

  // 모니터링
  useEffect(() => {
    console.log(inputs, user, channels, chats);
  }, [inputs, user, channels, chats]);

  // 이벤트 핸들러
  const handleInputs = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name } = e.target;
    let value;
    if (name === "name") {
      value = e.target.value;
    } else {
      value = parseInt(e.target.value);
    }
    setInputs({
      ...inputs,
      [name]: value,
    });
  };
  const handleUserName = () => {
    setUser({
      ...user,
      id: inputs.id,
      name: inputs.name,
    });
  };

  // 소켓 로직
  const subscribeNewChannel = () => {
    if (stompClient) {
      const chatMessage = {
        sender: user.id,
        receiver: inputs.newChannel,
        status: "CHANNEL_IN",
      };
      stompClient.send("/channel/" + user.id, {}, JSON.stringify(chatMessage));
    }
  };
  const onInfoReceived = (payload: Message) => {
    const payloadData = JSON.parse(payload.body);
    console.log(payloadData);
    switch (payloadData.status) {
      case "LOGIN":
        setChannels(payloadData.channels);
        break;
      case "UPDATE":
        setChannels([...channels, payloadData.channel]);
        break;
      case "LOGOUT":
        setChannels([]);
        break;
    }
  };
  const onMessageReceived = (payload: Message) => {
    const payloadData = JSON.parse(payload.body);
    console.log(payloadData);
    switch (payloadData.status) {
      case "CHANNEL_IN":
        break;
      case "CHANNEL_OUT":
        break;
      case "MESSAGE_TXT":
        break;
    }
  };
  const onConnected = () => {
    setUser({ ...user, connected: true });
    stompClient?.subscribe("/app/channel/" + user.id, onInfoReceived);
    channels.map((channel) => {
      stompClient?.subscribe("/app/channel/" + channel.id, onMessageReceived);
    });
  };
  const onError = (err: Frame | string) => {
    console.log(err);
    setUser({
      ...user,
      connected: false,
    });
  };
  const connect = () => {
    let Sock = new SockJS("http://70.12.247.45:8080/ws");
    stompClient = over(Sock);
    stompClient.connect({}, onConnected, onError);
  };
  const login = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    connect();
  };

  return (
    <div className="container">
      <form className="login input-box" onSubmit={login}>
        <input
          id="user-name"
          name="name"
          placeholder="이름을 입력하세요."
          onChange={handleInputs}
          value={inputs.name}
          disabled={user.loggedin}
        />
        <input
          id="user-id"
          name="id"
          placeholder="ID를 입력하세요."
          onChange={handleInputs}
          value={inputs.id}
          disabled={user.loggedin}
        />
        <button type="button" onClick={handleUserName} disabled={user.loggedin}>
          저장
        </button>
        <button disabled={!user.loggedin && user.connected}>로그인</button>
      </form>
      {user.name ? (
        user.connected ? (
          <div className="channel-list">
            <div className="new-channel">
              <input
                id="new-channel"
                name="newChannel"
                placeholder="채널 ID를 입력하세요."
                onChange={handleInputs}
                value={inputs.newChannel}
              />
              <button type="button" onClick={subscribeNewChannel}>
                저장
              </button>
            </div>
            <ul>
              {channels?.map((channel, index) => (
                <li
                  onClick={() => {
                    setTab(channel.name);
                  }}
                  className={`channel ${tab === channel.name && "active"}`}
                  key={index}
                >
                  {channel.name}
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="unselected">로딩중...</div>
        )
      ) : (
        <div className="unselected">로그인 해주세요.</div>
      )}
      {tab ? (
        <div className="chat-content">
          <ul className="chat-messages">
            {chats.map((chat, index) => (
              <li
                className={`message ${chat.sender === user.name && "self"}`}
                key={index}
              >
                {chat.sender !== user.name && (
                  <div className="avatar">{chat.sender}</div>
                )}
                <div className="message-data">{chat.content}</div>
                {chat.sender === user.name && (
                  <div className="avatar self">{chat.sender}</div>
                )}
              </li>
            ))}
          </ul>
          <div className="send-message input-box">
            <input
              type="text"
              className="input-message"
              placeholder="메세지를 입력하세요."
              // value={userData.message}
              // onChange={handleMessage}
            />
            <button
              type="button"
              className="send-button"
              // onClick={sendPrivateValue}
            >
              보내기
            </button>
          </div>
        </div>
      ) : (
        <div className="unselected">채팅방을 선택해 주세요.</div>
      )}
    </div>
  );
};

export default ChatRoom;
