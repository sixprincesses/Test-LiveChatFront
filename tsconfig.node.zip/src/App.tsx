import ChatRoom from "./components/ChatRoom";

function App() {
  return (
    <>
      <ChatRoom />
    </>
  );
}

export default App;
